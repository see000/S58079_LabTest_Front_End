$(function () {

    var link1 = crossroads.addRoute('', function (id) {
        query = window.location.search;
        urlParam = new URLSearchParams(query);
        var id = urlParam.get('id');

        var datalist = "id=" + id;

        $.ajax({
            type: "post",
            url: "https://kerbau.odaje.biz/getstaffbyid.php",
            data: datalist,
            cache: false,
            success: function (datareceived) {

                var dataGet = JSON.parse(datareceived);

                htmlText = "";
                htmlText =
                    "<tr><td>" + dataGet.employeeNumber + "</td></tr>" +
                    "<tr><td>FirstName</td><td>" + dataGet.firstName + "</td></tr>" +
                    "<tr><td>LastName</td><td>" + dataGet.lastName + "</td></tr>" +
                    "<tr><td>Office Code</td><td>" + dataGet.officeCode + "</td></tr>" +
                    "<tr><td>Phone Extension</td><td>" + dataGet.extension + "</td></tr>" +
                    "<tr><td>Email Address</td><td>" + dataGet.email + "</td></tr>" +
                    "<tr><td>Job Title</td><td>" + dataGet.jobTitle + "</td></tr>" +
                    "<tr><td>Reports To</td><td>" + dataGet.reportsTo + "</td></tr>";

                $('#maintable tbody').html(htmlText);
                
                

            },

            error: function () {
                alert("Data get Error. Try Again!")
            }
        });
    });

    

});
