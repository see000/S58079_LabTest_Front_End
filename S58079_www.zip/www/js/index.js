$(function () {



    var link1 = crossroads.addRoute('', function () {

        $.ajax({
            type: "get",
            url: "https://kerbau.odaje.biz/getstaff.php ",
            datalist: '',
            cache: false,
            success: function (returnedData) {
                alert("data requested successfully.")
                var length = results.rows.length;
                var newData = JSON.parse(returnedData);

                if (newData.status === 1) {
                    console.log(Json.parse(newData[1].employeeNumber));
                    htmlText = "";
                    $.each(newData, function (i, newData) {
                        secondpage = "<a href = 'secondpage.html?id=" + newData.employeeNumber + "' > " + newData.email + "</a > "

                        htmlText = htmlText + "<tr><td>" + secondpage + "</td></tr>";
                    });

                    $('#maintable tbody').html(htmlText);

                }




            },
            error: function () {
                alert("Failed to load All Employee!")
            }
        });


    });




});




